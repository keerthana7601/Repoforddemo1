abstract class Member{
	abstract void welcomeMessage();
}

class Student extends Member {
	
	public void welcomeMessage() {
		System.out.println("Hello Student...");
	}
	
}

class Teacher extends Member{
	public void welcomeMessage() {
		System.out.println("Hello Teacher...");
	}
	
}

class Staff extends Member{
	public void welcomeMessage() {
		System.out.println("Hello Staff...");
	}
	
}
public class AbstractionDemo {

	public static void main(String[] args) {
	
         Student s = new Student();
         Teacher t = new Teacher();
         Staff st = new  Staff();
         
         Member m[] = new Member[4];
         
         m[0]=new Student();
         m[1]=new Student();
         m[2]=new Teacher();
         m[3]=new Staff();
         
         for(Member m1:m) {
        	 m1.welcomeMessage();
         }
         
	}

}
